# 📊 Servidor MCP para Microsoft Excel

[![MCP](https://img.shields.io/badge/MCP-Model%20Context%20Protocol-blue.svg)](https://modelcontextprotocol.io/)
[![Node.js](https://img.shields.io/badge/Node.js-%3E%3D18.0.0-green.svg)](https://nodejs.org/)
[![Platform](https://img.shields.io/badge/Platform-macOS-lightgrey.svg)](https://www.apple.com/macos/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

Servidor **MCP (Model Context Protocol)** que permite a asistentes de Inteligencia Artificial (opencode, Claude Desktop, Antigravity, Cursor, etc.) **leer, escribir y operar en tiempo real sobre Microsoft Excel** en macOS utilizando AppleScript nativo.

Está especialmente diseñado para asistir en **ejercicios contables, finanzas y modelamiento en hojas de cálculo**: crear libros de trabajo, registrar asientos contables, evaluar fórmulas dinámicas, leer rangos activos y guardar resultados de forma segura.

---

## 🛠️ Herramientas Disponibles (8 Tools)

| Herramienta | Descripción | Modo | Confirmación Requerida |
|---|---|:---:|:---:|
| `estado_excel` | Informa si Excel está instalado, en ejecución, versión, libros abiertos y hoja activa. | Lectura | No |
| `listar_libros` | Lista todos los libros abiertos, rutas de archivo y hojas, identificando los activos. | Lectura | No |
| `leer_rango` | Lee un rango de celdas A1 (ej: `A1:D20`) y devuelve los valores tabulares evaluados. | Lectura | No |
| `abrir_libro` | Abre un archivo existente (`.xlsx`, `.xlsm`, `.xls`, `.xlsb`, `.csv`) desde una ruta absoluta. | Acción | No |
| `crear_libro` | Crea un libro de trabajo nuevo en blanco sin guardar. | Escritura | No |
| `crear_hoja` | Agrega una hoja nueva al final del libro de trabajo especificado o activo. | Escritura | No |
| `escribir_rango` | Escribe una matriz de valores o fórmulas desde una celda inicial. | Escritura / Destructiva | **Sí** (`confirmar: true`) |
| `guardar_libro` | Guarda el libro en una ruta absoluta (`.xlsx`, `.xlsm`, `.xls`, `.csv`). | Escritura / Destructiva | **Sí** (`confirmar: true`) |

> [!NOTE]
> Por seguridad, las herramientas que sobrescriben celdas o archivos (`escribir_rango` y `guardar_libro`) exigen el parámetro obligatorio `confirmar: true` y declaran `destructiveHint: true` en sus anotaciones MCP.

---

## 📋 Requisitos del Sistema

- **macOS** (utiliza AppleScript nativo vía `/usr/bin/osascript`).
- **Microsoft Excel para Mac** instalado en `/Applications/Microsoft Excel.app`.
- **Node.js 18** o superior.
- **Permiso de Automatización** en macOS (para enviar eventos a Microsoft Excel).

---

## 🚀 Instalación y Compilación

1. **Clonar el repositorio:**
   ```bash
   git clone https://github.com/tu-usuario/mcp-microsoft-excel.git
   cd mcp-microsoft-excel
   ```

2. **Instalar dependencias:**
   ```bash
   npm install
   ```

3. **Compilar el proyecto:**
   ```bash
   npm run build
   ```
   *Esto compila el código TypeScript de `src/` a JavaScript ejecutable en `dist/`.*

4. **Ejecutar prueba de verificación (Smoke Test):**
   ```bash
   npm test
   ```
   *Verifica el handshake del protocolo MCP, el listado de herramientas y los esquemas de validación Zod.*

---

## 🔌 Configuración en Clientes MCP

### 1. opencode

El proyecto incluye el archivo `opencode.json` listo para usar con ruta relativa.

Para registrar el servidor con la ruta absoluta automáticamente en tu configuración local o global:

```bash
# Registrar en el opencode.json del proyecto actual:
node scripts/configurar-opencode.mjs --nombre=microsoft-excel

# O registrarlo globalmente para usarlo desde cualquier directorio:
node scripts/configurar-opencode.mjs --global --nombre=microsoft-excel
```

También puedes iniciar Excel y opencode de forma sincronizada usando el lanzador:
- En macOS: doble clic a `Abrir-microsoft-excel.command` (o ejecutar `bash Abrir-microsoft-excel.command`).
- En Windows: doble clic a `Abrir-microsoft-excel.bat`.

### 2. Claude Desktop

Agrega el servidor a tu archivo de configuración de Claude Desktop:

**Ruta en macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "microsoft-excel": {
      "command": "node",
      "args": [
        "/ruta/absoluta/a/mcp-microsoft-excel/dist/index.js"
      ]
    }
  }
}
```

### 3. Antigravity IDE / Cursor / Otros Clientes

```json
{
  "mcpServers": {
    "microsoft-excel": {
      "command": "node",
      "args": [
        "${workspaceFolder}/dist/index.js"
      ]
    }
  }
}
```

---

## 🔐 Permiso de Automatización en macOS

La primera vez que el servidor intente comunicarse con Excel, macOS solicitará autorización de **Eventos de Apple (AppleScript)** o podría mostrar el error `-1743`.

Para autorizarlo manualmente:
1. Abre **Ajustes del Sistema** en tu Mac.
2. Ve a **Privacidad y seguridad > Automatización**.
3. Localiza la aplicación cliente (por ejemplo, **Terminal**, **iTerm**, **opencode** o **Claude**).
4. Asegúrate de que la casilla **Microsoft Excel** esté activada (✓).
5. Reinicia la terminal o la aplicación cliente para que los cambios surtan efecto.

---

## 💡 Ejemplos de Uso con el Asistente de IA

Una vez conectado el MCP, puedes pedirle a tu asistente en lenguaje natural:

1. **Creación de Asientos Contables:**
   > *"Crea un libro nuevo en Excel, agrega una hoja llamada `Libro Diario` y registra el siguiente asiento: Fecha 2026-03-01, Cuenta Caja en el Debe por 2.500.000, y Cuenta Capital en el Haber por 2.500.000."*

2. **Auditoría y Revisión:**
   > *"Lee el rango `A1:F20` de la hoja activa en Excel y revisa si la columna Debe y Haber están cuadradas, explicando cualquier descuadre que encuentres."*

3. **Cálculos y Fórmulas:**
   > *"En la celda `E2` escribe la fórmula `=C2-D2`, replícala hasta la fila 10 y guarda el libro en `/Users/tu-usuario/Documentos/ejercicio_contable.xlsx`."*

---

## 🛡️ Seguridad y Buenas Prácticas

- **Sin credenciales secretas:** Este MCP se ejecuta 100% de manera local; no requiere ni almacena claves de API ni credenciales de usuario.
- **Validación rigurosa de entradas:** Todas las rutas, nombres de hoja y rangos A1 son validados mediante esquemas [Zod](https://zod.dev/) antes de interactuar con el sistema operativo.
- **Ejecución segura de comandos:** Los scripts se ejecutan mediante `execFile` con argumentos separados, previniendo cualquier tipo de inyección de comandos en la terminal.
- **Protección contra sobrescrituras accidentales:** Cualquier acción de modificación destructiva exige confirmación explícita del usuario (`confirmar: true`).

---

## 🧪 Desarrollo y Pruebas Visuales

Para probar las herramientas visualmente mediante el inspector interactivo oficial de MCP:

```bash
npm run inspect
```

Para crear una nueva herramienta siguiendo las convenciones del proyecto:

```bash
npm run new-tool -- nombre_de_herramienta
```

---

## 📄 Licencia

Este proyecto está distribuido bajo la licencia [MIT](LICENSE).
