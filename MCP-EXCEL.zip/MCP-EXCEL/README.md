# MCP de Microsoft Excel

Servidor MCP que permite a un asistente de IA **leer y escribir en Microsoft Excel**
de macOS usando AppleScript. Está pensado para apoyar ejercicios de contabilidad:
crear un libro, escribir asientos o tablas, usar fórmulas y guardar el resultado.

El chat también puede responder preguntas sobre la materia; eso lo hace el propio
modelo. Este MCP se encarga de la parte práctica: llevar los datos a Excel.

## Herramientas

| Herramienta | Qué hace | ¿Modifica datos? |
|---|---|---|
| `estado_excel` | Informa si Excel está instalado/abierto, su versión, libros abiertos y hoja activa. | No |
| `listar_libros` | Lista libros abiertos, rutas y hojas, marcando el libro y la hoja activos. | No |
| `leer_rango` | Lee un rango A1 (por ejemplo `A1:D20`) y devuelve sus valores. | No |
| `abrir_libro` | Abre un archivo `.xlsx`, `.xlsm`, `.xls`, `.xlsb` o `.csv` desde una ruta absoluta. | No modifica celdas, pero abre la app/archivo |
| `crear_libro` | Crea un libro nuevo sin guardar. | Sí (crea un libro) |
| `crear_hoja` | Agrega una hoja nueva al final de un libro. | Sí (crea una hoja) |
| `escribir_rango` | Escribe una matriz de valores o fórmulas desde una celda inicial. **Exige `confirmar: true`.** | Sí (sobrescribe celdas) |
| `guardar_libro` | Guarda un libro en una ruta absoluta. **Exige `confirmar: true`.** | Sí (puede sobrescribir el archivo) |

Las herramientas destructivas (`escribir_rango` y `guardar_libro`) exigen el
parámetro `confirmar: true`. Las de escritura también declaran
`destructiveHint: true` en sus anotaciones.

## Ejemplos de frases para pedirle a la IA

1. "Crea un libro nuevo, ponle una hoja llamada `Ejercicio1` y escribe el asiento:
   fecha 2026-01-01, cuenta Caja, debe 1.000.000, haber 0."
2. "Lee el rango `A1:F15` de la hoja activa y explícame qué errores de contabilidad
   ves en esos asientos."
3. "En la celda `E2` escribe la fórmula `=D2-C2`, copia la fórmula hasta `E10` y
   guarda el libro en `/Users/tu-usuario/Documentos/ejercicio.xlsx`."

## Requisitos

- macOS.
- Microsoft Excel instalado en `/Applications/Microsoft Excel.app`.
- Node.js 18 o superior.
- Permiso de **Automatización** para que Terminal u opencode controle Excel.

## Instalación y prueba

```bash
npm install
npm run build
npm test
```

`npm test` compila y verifica el handshake MCP, el listado de herramientas y sus
descripciones. Para probar visualmente:

```bash
npm run inspect
```

Para registrar el MCP en el `opencode.json` de este proyecto con la ruta absoluta:

```bash
node scripts/configurar-opencode.mjs --nombre=microsoft-excel
```

El lanzador `Abrir-microsoft-excel.command` (macOS) o el `.bat` (Windows) abre Excel
y opencode a la vez y registra el MCP automáticamente.

## Permiso de Automatización en macOS

La primera vez que el MCP intente controlar Excel, macOS puede mostrar un aviso o
bloquear la operación con el error `-1743`. Para autorizarlo:

1. Abre **Ajustes del Sistema**.
2. Ve a **Privacidad y seguridad > Automatización**.
3. Activa el permiso para **Terminal** (o para la app desde la que ejecutes opencode)
   y marca **Microsoft Excel**.
4. Cierra y vuelve a abrir la terminal/opencode si el permiso no se aplica al instante.

Si Excel está cerrado, las herramientas de lectura/escritura devuelven un error
explicativo. Usa `abrir_libro` o `crear_libro` para iniciarlo.

## Limitaciones conocidas

- Solo funciona en **macOS** (usa AppleScript mediante `osascript`).
- Los diálogos de Excel (contraseña, vínculos externos, archivo ocupado) pueden
  bloquear una operación hasta que el usuario los responda.
- `leer_rango` devuelve una tabla de texto; los saltos de línea y tabulaciones dentro
  de una celda se reemplazan por espacios.
- Las fechas y monedas se devuelven con el formato visible de Excel.
- `guardar_libro` admite `.xlsx`, `.xlsm`, `.xls` y `.csv`.
- **No se pudieron ejecutar pruebas reales de lectura/escritura contra Excel** porque
  el permiso de Automatización de macOS estaba bloqueado durante la verificación
  (`-1743`). El código, la compilación y el smoke test sí están verificados. Cuando
  concedas el permiso, conviene probar primero `estado_excel`, luego `listar_libros`
  y después `leer_rango` antes de usar las herramientas de escritura.
