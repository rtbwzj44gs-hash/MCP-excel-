# Investigación: controlar Microsoft Excel en macOS

## Datos del equipo

- Aplicación: **Microsoft Excel 16.114.4**
- Ruta: `/Applications/Microsoft Excel.app`
- Identificador: `com.microsoft.Excel`
- Sistema: macOS
- Binario principal: `Contents/MacOS/Microsoft Excel` (no es una CLI)

## Vías evaluadas

### 1. API HTTP / WebSocket / plugin oficial

No se encontró una API local documentada de Excel para macOS. Los esquemas de URL
declarados por la app son `launch-excel`, `open-excel`, `ms-excel` y `excel`; sirven
para abrir archivos, no para leer o escribir celdas. No se usó esta vía.

### 2. CLI de la aplicación

El único ejecutable dentro de `Contents/MacOS` es el binario de la app. No hay una
CLI tipo `excel --help` para manipular libros. Descartada.

### 3. Archivos de datos

Un `.xlsx` se puede leer y escribir con librerías como `exceljs`. Sería útil para
procesar archivos cerrados, pero no controla la ventana abierta de Excel ni refleja
cambios en vivo. Además agregaría una dependencia que el proyecto no tiene. Se
descartó como vía principal, aunque queda como alternativa futura.

### 4. AppleScript / JXA (vía elegida)

Excel para Mac es scriptable. La app incluye su diccionario en:

`/Applications/Microsoft Excel.app/Contents/Resources/Excel.sdef`

El comando `sdef` del sistema no se pudo usar porque requiere Xcode completo, pero
el archivo `.sdef` se leyó directamente. De ahí se confirmaron los comandos y clases
necesarios:

- `make new workbook`
- `open workbook workbook file name ...`
- `save workbook as ... filename ...`
- `make new worksheet ... with properties {name:...}`
- `range "A1:D10" of ...`
- `value of range` (lista de listas para rangos)
- `formula of cell ...`
- `get resize ... row size ... column size ...`
- `get address ...`
- `cell "A1" of ...`
- `display alerts`

También se comprobó con una consulta de solo lectura que la app responde:

```text
osascript -e 'tell application "Microsoft Excel" to get version'
16.114.4
```

Por eso se implementó el MCP con `osascript` y AppleScript, pasando todos los
valores del modelo como **argumentos** (`argv`), nunca concatenados dentro del
script ni ejecutados por un shell.

### 5. Automatización de interfaz

No fue necesaria. Se descartó por ser la opción más frágil (depende de coordenadas,
ventanas y cambios visuales de la app).

## Limitaciones conocidas

- **Permiso de Automatización de macOS:** la primera vez que un proceso intenta
  controlar Excel, macOS pide permiso. En este equipo el intento devolvió `-1743`
  ("No tienes autorización para enviar eventos Apple"). Hay que autorizar Terminal
  u opencode en **Ajustes del Sistema > Privacidad y seguridad > Automatización**.
  Sin ese permiso las herramientas devuelven un error explicativo.
- Los diálogos propios de Excel (contraseña, vínculos externos, archivo ocupado)
  pueden bloquear la operación hasta que el usuario los responda.
- `leer_rango` devuelve una tabla de texto: los saltos de línea y tabulaciones
  dentro de una celda se reemplazan por espacios para no romper la tabla.
- Las fechas y monedas se muestran como Excel las formatea; no se convierten a
  tipos especiales.
- Solo funciona en **macOS**. En Windows habría que usar COM/PowerShell y en Linux
  otra vía.
- Las herramientas de lectura no se pudieron probar contra datos reales porque el
  permiso de Automatización estaba bloqueado en el momento de la verificación.
