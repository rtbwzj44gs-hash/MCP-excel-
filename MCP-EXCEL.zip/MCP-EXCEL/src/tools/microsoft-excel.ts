import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { existsSync, statSync } from "node:fs";
import path from "node:path";
import { z } from "zod";
import { run } from "../lib/exec.js";
import { error, json, texto } from "../lib/respuestas.js";

const RUTA_EXCEL = "/Applications/Microsoft Excel.app";
const RUTA_BINARIO = "/Microsoft Excel.app/Contents/MacOS/Microsoft Excel";

const EXTENSIONES_ABRIR = new Set([".xlsx", ".xlsm", ".xls", ".xlsb", ".csv"]);
const EXTENSIONES_GUARDAR = new Set([".xlsx", ".xlsm", ".xls", ".csv"]);

const RANGO_A1 = /^[A-Za-z]{1,3}[1-9][0-9]{0,6}(?::[A-Za-z]{1,3}[1-9][0-9]{0,6})?$/;
const NOMBRE_HOJA = /^[^\\/?*[\]:]{1,31}$/;

const valorSchema = z.union([z.string(), z.number(), z.boolean(), z.null()]);
type Valor = z.infer<typeof valorSchema>;

type EjecucionOk = { ok: true; salida: string };
type EjecucionError = { ok: false; mensaje: string };

function excelInstalado(): boolean {
  return existsSync(RUTA_EXCEL);
}

async function excelEnEjecucion(): Promise<boolean> {
  const r = await run("/usr/bin/pgrep", ["-f", RUTA_BINARIO], { timeoutMs: 5_000 });
  return r.code === 0;
}

function mensajeDeError(stderr: string, code: number): string {
  const detalle = stderr.trim();

  if (
    /-1743|No tienes autorizaci[oó]n|Not authorized to send Apple events|not allowed to send Apple events/i.test(
      detalle,
    )
  ) {
    return "macOS bloqueó el control de Microsoft Excel. Abre Ajustes del Sistema > Privacidad y seguridad > Automatización y permite que Terminal (u opencode) controle Microsoft Excel. Después vuelve a intentarlo.";
  }
  if (/isn't running|is not running|no se est[aá] ejecutando|not running/i.test(detalle)) {
    return "Microsoft Excel no está abierto. Ábrelo o usa la herramienta abrir_libro (o crear_libro) para iniciarlo.";
  }
  if (/already exists|ya existe/i.test(detalle)) {
    return "Ya existe una hoja o un archivo con ese nombre. Elige otro nombre o elimina el existente antes de continuar.";
  }
  if (/read-only|solo lectura|password|contrase[nñ]a/i.test(detalle)) {
    return "El libro está protegido o abierto en solo lectura. Quita la protección o abre una copia editable antes de modificarlo.";
  }
  if (
    /does not exist|no existe|Can't get|No se puede obtener|invalid range|rango no v[aá]lido/i.test(detalle)
  ) {
    return "No se encontró el libro, la hoja o el rango indicado. Revisa los nombres exactos con listar_libros y usa direcciones A1 como A1 o B2:D10.";
  }
  if (/timed out|timeout|tard[oó] demasiado/i.test(detalle)) {
    return "La operación tardó demasiado. Si Excel muestra un diálogo (permiso, contraseña o archivo), respóndelo y vuelve a intentarlo.";
  }

  return `AppleScript devolvió un error (código ${code}): ${detalle || "sin detalle"}`;
}

async function ejecutarAppleScript(
  script: string,
  args: string[],
  timeoutMs = 30_000,
): Promise<EjecucionOk | EjecucionError> {
  if (process.platform !== "darwin") {
    return {
      ok: false,
      mensaje:
        "Este MCP controla Microsoft Excel mediante AppleScript y solo funciona en macOS. En Windows o Linux habría que usar otra vía de integración.",
    };
  }

  const r = await run("/usr/bin/osascript", ["-e", script, ...args], { timeoutMs });
  if (r.code === 0) return { ok: true, salida: r.stdout.trim() };
  return { ok: false, mensaje: mensajeDeError(r.stderr, r.code) };
}

async function comprobarEntorno(
  requiereAbierto: boolean,
): Promise<{ ok: true } | { ok: false; mensaje: string }> {
  if (process.platform !== "darwin") {
    return {
      ok: false,
      mensaje:
        "Este MCP usa AppleScript y solo funciona en macOS. En otro sistema operativo se necesitaría una integración distinta.",
    };
  }
  if (!excelInstalado()) {
    return {
      ok: false,
      mensaje:
        "Microsoft Excel no está instalado en /Applications/Microsoft Excel.app. Instálalo desde Microsoft 365 o la App Store.",
    };
  }
  if (requiereAbierto && !(await excelEnEjecucion())) {
    return {
      ok: false,
      mensaje:
        "Microsoft Excel no está abierto. Ábrelo o usa la herramienta abrir_libro (o crear_libro) para iniciarlo.",
    };
  }
  return { ok: true };
}

function validarRuta(ruta: string, extensiones: Set<string>, debeExistir: boolean): string | null {
  if (!path.isAbsolute(ruta)) {
    return "La ruta debe ser absoluta, por ejemplo /Users/tu-usuario/Documentos/libro.xlsx.";
  }
  if (ruta.includes("\0")) return "La ruta contiene caracteres no válidos.";
  const extension = path.extname(ruta).toLowerCase();
  if (!extensiones.has(extension)) {
    return `Extensión no admitida (${extension || "sin extensión"}). Usa una de estas: ${[...extensiones].join(", ")}.`;
  }
  if (debeExistir) {
    if (!existsSync(ruta)) return `No existe el archivo: ${ruta}`;
    if (!statSync(ruta).isFile()) return `La ruta no apunta a un archivo: ${ruta}`;
  } else {
    const carpeta = path.dirname(ruta);
    if (!existsSync(carpeta) || !statSync(carpeta).isDirectory()) {
      return `La carpeta de destino no existe: ${carpeta}`;
    }
  }
  return null;
}

function parsearCeldaInicial(rango: string): { fila: number; columna: number } | null {
  const base = rango.split(":")[0] ?? "";
  const m = /^([A-Za-z]{1,3})([1-9][0-9]{0,6})$/.exec(base);
  if (!m) return null;

  const letras = (m[1] ?? "").toUpperCase();
  let columna = 0;
  for (const letra of letras) {
    columna = columna * 26 + (letra.charCodeAt(0) - 64);
  }
  return { fila: Number(m[2]), columna };
}

function letraColumna(numero: number): string {
  let resultado = "";
  let n = numero;
  while (n > 0) {
    const resto = (n - 1) % 26;
    resultado = String.fromCharCode(65 + resto) + resultado;
    n = Math.floor((n - 1) / 26);
  }
  return resultado;
}

function direccionCelda(fila: number, columna: number): string {
  return `${letraColumna(columna)}${fila}`;
}

function codificarValor(valor: Valor): string {
  if (valor === null) return "S:";
  if (typeof valor === "number") return `N:${valor}`;
  if (typeof valor === "boolean") return `B:${valor ? "1" : "0"}`;
  return `S:${valor}`;
}

const SCRIPT_ESTADO = `
on run argv
  tell application "Microsoft Excel"
    set v to version
    set wbCount to count of workbooks
    set out to "version=" & v & linefeed & "workbooks=" & (wbCount as text)
    if wbCount > 0 then
      set aw to active workbook
      try
        set out to out & linefeed & "active_workbook=" & (name of aw)
      end try
      try
        set out to out & linefeed & "active_full_name=" & (full name of aw)
      end try
      try
        set out to out & linefeed & "active_sheet=" & (name of active sheet of aw)
      end try
    end if
    return out
  end tell
end run
`;

const SCRIPT_LISTAR = `
on run argv
  tell application "Microsoft Excel"
    set wbCount to count of workbooks
    if wbCount is 0 then return ""
    set activeWbName to ""
    try
      set activeWbName to name of active workbook
    end try
    set out to {}
    repeat with wb in workbooks
      set wbName to ""
      set wbFullName to ""
      try
        set wbName to name of wb
      end try
      try
        set wbFullName to full name of wb
      end try
      set isActiveWb to (wbName is activeWbName)
      set activeSheetName to ""
      if isActiveWb then
        try
          set activeSheetName to name of active sheet of wb
        end try
      end if
      repeat with sh in sheets of wb
        set shName to ""
        try
          set shName to name of sh
        end try
        set isActiveSh to (isActiveWb and (shName is activeSheetName))
        set end of out to wbName & tab & wbFullName & tab & shName & tab & (isActiveWb as text) & tab & (isActiveSh as text)
      end repeat
    end repeat
    return my unir(out, linefeed)
  end tell
end run

on unir(lista, sep)
  set oldDelims to AppleScript's text item delimiters
  set AppleScript's text item delimiters to sep
  set texto to lista as text
  set AppleScript's text item delimiters to oldDelims
  return texto
end unir
`;

const SCRIPT_LEER = `
on run argv
  set wbArg to item 1 of argv
  set shArg to item 2 of argv
  set rngArg to item 3 of argv
  tell application "Microsoft Excel"
    if wbArg is "" then
      set wb to active workbook
    else
      set wb to workbook wbArg
    end if
    if shArg is "" then
      set sh to active sheet of wb
    else
      set sh to worksheet shArg of wb
    end if
    set rng to range rngArg of sh
    set addr to get address of rng
    set vals to value of rng
    return addr & linefeed & my tabla(vals)
  end tell
end run

on tabla(v)
  if class of v is list then
    set out to ""
    repeat with i from 1 to count of v
      set itemI to item i of v
      if class of itemI is list then
        set out to out & my fila(itemI) & linefeed
      else
        set out to out & my celda(itemI) & linefeed
      end if
    end repeat
    return out
  else
    return my celda(v)
  end if
end tabla

on fila(valores)
  set out to ""
  repeat with i from 1 to count of valores
    if i > 1 then set out to out & tab
    set out to out & my celda(item i of valores)
  end repeat
  return out
end fila

on celda(v)
  if v is missing value then return ""
  try
    set t to v as text
    set t to my reemplazar(t, linefeed, " ")
    set t to my reemplazar(t, return, " ")
    set t to my reemplazar(t, tab, " ")
    return t
  on error
    return ""
  end try
end celda

on reemplazar(t, buscar, poner)
  set oldDelims to AppleScript's text item delimiters
  set AppleScript's text item delimiters to buscar
  set partes to text items of (t as text)
  set AppleScript's text item delimiters to poner
  set texto to partes as text
  set AppleScript's text item delimiters to oldDelims
  return texto
end reemplazar
`;

const SCRIPT_ESCRIBIR = `
on run argv
  set wbArg to item 1 of argv
  set shArg to item 2 of argv
  set rngArg to item 3 of argv
  set nRows to (item 4 of argv) as integer
  set nCols to (item 5 of argv) as integer
  set nFormulas to (item 6 of argv) as integer

  set vals to {}
  set idx to 7
  repeat with r from 1 to nRows
    set fila to {}
    repeat with c from 1 to nCols
      set end of fila to my decodificar(item idx of argv)
      set idx to idx + 1
    end repeat
    set end of vals to fila
  end repeat

  set formulas to {}
  repeat with i from 1 to nFormulas
    set dir to item idx of argv
    set formulaTxt to item (idx + 1) of argv
    set idx to idx + 2
    set end of formulas to {dir, formulaTxt}
  end repeat

  tell application "Microsoft Excel"
    if wbArg is "" then
      set wb to active workbook
    else
      set wb to workbook wbArg
    end if
    if shArg is "" then
      set sh to active sheet of wb
    else
      set sh to worksheet shArg of wb
    end if

    set baseRng to range rngArg of sh
    set rng to get resize baseRng row size nRows column size nCols
    set value of rng to vals

    repeat with par in formulas
      set dir to item 1 of par
      set formulaTxt to item 2 of par
      set formula of cell dir of sh to formulaTxt
    end repeat

    return get address of rng
  end tell
end run

on decodificar(s)
  set s to s as text
  if s is "S:" then return ""
  if s starts with "N:" then
    return (text 3 thru -1 of s) as number
  else if s starts with "B:" then
    if (text 3 thru -1 of s) is "1" then return true
    return false
  else if s starts with "S:" then
    return text 3 thru -1 of s
  else
    return s
  end if
end decodificar
`;

const SCRIPT_CREAR_LIBRO = `
on run argv
  tell application "Microsoft Excel"
    set wb to make new workbook
    return name of wb
  end tell
end run
`;

const SCRIPT_ABRIR_LIBRO = `
on run argv
  set ruta to item 1 of argv
  tell application "Microsoft Excel"
    set wb to open workbook workbook file name ruta
    return name of wb
  end tell
end run
`;

const SCRIPT_CREAR_HOJA = `
on run argv
  set wbArg to item 1 of argv
  set nombre to item 2 of argv
  tell application "Microsoft Excel"
    if wbArg is "" then
      set wb to active workbook
    else
      set wb to workbook wbArg
    end if
    set nueva to make new worksheet at end of wb with properties {name:nombre}
    return name of nueva
  end tell
end run
`;

const SCRIPT_GUARDAR = `
on run argv
  set wbArg to item 1 of argv
  set ruta to item 2 of argv
  tell application "Microsoft Excel"
    if wbArg is "" then
      set wb to active workbook
    else
      set wb to workbook wbArg
    end if
    set oldAlerts to display alerts
    set display alerts to false
    try
      save workbook as wb filename ruta
    on error errMsg number errNum
      set display alerts to oldAlerts
      error errMsg number errNum
    end try
    set display alerts to oldAlerts
    return ruta
  end tell
end run
`;

export function register(server: McpServer): void {
  server.registerTool(
    "estado_excel",
    {
      title: "Estado de Microsoft Excel",
      description:
        "Informa si Microsoft Excel está instalado y abierto, su versión, los libros abiertos y la hoja activa. Úsala para comprobar la conexión antes de leer o escribir datos.",
      inputSchema: {},
      annotations: { readOnlyHint: true },
    },
    async () => {
      if (process.platform !== "darwin") {
        return error("Este MCP usa AppleScript y solo funciona en macOS.");
      }
      if (!excelInstalado()) {
        return json({
          instalado: false,
          ejecutandose: false,
          nota: "Instala Microsoft Excel en /Applications para poder controlarlo.",
        });
      }

      const versionInstaladaResult = await run(
        "/usr/bin/plutil",
        [
          "-extract",
          "CFBundleShortVersionString",
          "raw",
          "-o",
          "-",
          `${RUTA_EXCEL}/Contents/Info.plist`,
        ],
        { timeoutMs: 5_000 },
      );
      const versionInstalada =
        versionInstaladaResult.code === 0 ? versionInstaladaResult.stdout.trim() : null;

      if (!(await excelEnEjecucion())) {
        return json({
          instalado: true,
          ejecutandose: false,
          version_instalada: versionInstalada,
          nota: "Excel está instalado pero cerrado. Ábrelo o usa abrir_libro/crear_libro para empezar.",
        });
      }

      const r = await ejecutarAppleScript(SCRIPT_ESTADO, [], 30_000);
      if (!r.ok) return error(r.mensaje);

      const datos: Record<string, string> = {};
      for (const linea of r.salida.split(/\r?\n/)) {
        const separador = linea.indexOf("=");
        if (separador > 0) {
          datos[linea.slice(0, separador)] = linea.slice(separador + 1);
        }
      }

      return json({
        instalado: true,
        ejecutandose: true,
        version: datos.version ?? null,
        version_instalada: versionInstalada,
        libros_abiertos: Number(datos.workbooks ?? "0"),
        libro_activo: datos.active_workbook ?? null,
        ruta_libro_activo: datos.active_full_name ?? null,
        hoja_activa: datos.active_sheet ?? null,
        permiso_automatizacion: "correcto",
      });
    },
  );

  server.registerTool(
    "listar_libros",
    {
      title: "Listar libros y hojas abiertas",
      description:
        "Lista los libros de Excel abiertos, su ruta y sus hojas, indicando cuál es el libro y la hoja activos. Úsala para descubrir nombres exactos antes de leer o escribir.",
      inputSchema: {},
      annotations: { readOnlyHint: true },
    },
    async () => {
      const entorno = await comprobarEntorno(true);
      if (!entorno.ok) return error(entorno.mensaje);

      const r = await ejecutarAppleScript(SCRIPT_LISTAR, [], 30_000);
      if (!r.ok) return error(r.mensaje);

      const libros = new Map<
        string,
        { libro: string; ruta: string; activo: boolean; hojas: { nombre: string; activa: boolean }[] }
      >();

      if (r.salida) {
        for (const linea of r.salida.split(/\r?\n/)) {
          const [libro, ruta, hoja, activo, hojaActiva] = linea.split("\t");
          if (!libro) continue;
          if (!libros.has(libro)) {
            libros.set(libro, { libro, ruta: ruta ?? "", activo: activo === "true", hojas: [] });
          }
          const entrada = libros.get(libro);
          if (entrada && hoja) {
            entrada.hojas.push({ nombre: hoja, activa: hojaActiva === "true" });
          }
        }
      }

      return json({ libros: [...libros.values()] });
    },
  );

  server.registerTool(
    "leer_rango",
    {
      title: "Leer un rango de celdas",
      description:
        "Devuelve los valores de un rango de una hoja de Excel, por ejemplo A1:D20. Úsala para revisar datos, saldos, asientos o cualquier tabla antes de modificarla.",
      inputSchema: {
        libro: z
          .string()
          .trim()
          .max(255)
          .optional()
          .describe("Nombre exacto del libro abierto. Si se omite, usa el libro activo."),
        hoja: z
          .string()
          .trim()
          .max(255)
          .optional()
          .describe("Nombre exacto de la hoja. Si se omite, usa la hoja activa."),
        rango: z
          .string()
          .trim()
          .regex(RANGO_A1, "Usa una dirección A1 válida, por ejemplo A1 o B2:D10.")
          .describe("Rango en notación A1 que se quiere leer, por ejemplo A1:D20."),
      },
      annotations: { readOnlyHint: true },
    },
    async ({ libro, hoja, rango }) => {
      const entorno = await comprobarEntorno(true);
      if (!entorno.ok) return error(entorno.mensaje);

      const r = await ejecutarAppleScript(SCRIPT_LEER, [libro ?? "", hoja ?? "", rango], 30_000);
      if (!r.ok) return error(r.mensaje);

      const lineas = r.salida.split(/\r?\n/);
      const direccion = lineas.shift() ?? rango;
      const filas = lineas.map((linea) => linea.split("\t"));

      return json({
        libro: libro || "(libro activo)",
        hoja: hoja || "(hoja activa)",
        direccion,
        filas,
      });
    },
  );

  server.registerTool(
    "abrir_libro",
    {
      title: "Abrir un libro de Excel",
      description:
        "Abre un archivo de Excel desde una ruta absoluta del computador. Úsala cuando el usuario mencione un archivo que aún no está abierto en Excel.",
      inputSchema: {
        ruta: z
          .string()
          .trim()
          .min(1)
          .max(1024)
          .describe("Ruta absoluta del archivo, por ejemplo /Users/ana/Documentos/contabilidad.xlsx."),
      },
      annotations: { readOnlyHint: false },
    },
    async ({ ruta }) => {
      const entorno = await comprobarEntorno(false);
      if (!entorno.ok) return error(entorno.mensaje);

      const problema = validarRuta(ruta, EXTENSIONES_ABRIR, true);
      if (problema) return error(problema);

      const r = await ejecutarAppleScript(SCRIPT_ABRIR_LIBRO, [ruta], 60_000);
      if (!r.ok) return error(r.mensaje);

      return texto(`Libro abierto: ${r.salida} (${ruta})`);
    },
  );

  server.registerTool(
    "crear_libro",
    {
      title: "Crear un libro nuevo",
      description:
        "Crea un libro nuevo sin guardar en Microsoft Excel. Úsala para empezar un ejercicio de contabilidad desde cero; después puedes escribir datos y guardarlo con guardar_libro.",
      inputSchema: {},
      annotations: { readOnlyHint: false },
    },
    async () => {
      const entorno = await comprobarEntorno(false);
      if (!entorno.ok) return error(entorno.mensaje);

      const r = await ejecutarAppleScript(SCRIPT_CREAR_LIBRO, [], 60_000);
      if (!r.ok) return error(r.mensaje);

      return texto(`Libro creado: ${r.salida}. Aún no está guardado; usa guardar_libro cuando termines.`);
    },
  );

  server.registerTool(
    "crear_hoja",
    {
      title: "Crear una hoja",
      description:
        "Agrega una hoja nueva al final de un libro abierto. Úsala para separar ejercicios, meses o secciones dentro del mismo libro.",
      inputSchema: {
        libro: z
          .string()
          .trim()
          .max(255)
          .optional()
          .describe("Nombre exacto del libro abierto. Si se omite, usa el libro activo."),
        nombre: z
          .string()
          .trim()
          .min(1)
          .max(31)
          .regex(
            NOMBRE_HOJA,
            "El nombre no puede contener \\ / ? * [ ] : ni superar 31 caracteres.",
          )
          .describe("Nombre de la hoja nueva, por ejemplo Ejercicio1 o Balance2026."),
      },
      annotations: { readOnlyHint: false },
    },
    async ({ libro, nombre }) => {
      const entorno = await comprobarEntorno(true);
      if (!entorno.ok) return error(entorno.mensaje);

      const r = await ejecutarAppleScript(SCRIPT_CREAR_HOJA, [libro ?? "", nombre], 30_000);
      if (!r.ok) return error(r.mensaje);

      return texto(`Hoja creada: ${r.salida}`);
    },
  );

  server.registerTool(
    "escribir_rango",
    {
      title: "Escribir valores o fórmulas",
      description:
        "Escribe una matriz de valores en Excel desde una celda inicial. Los textos que empiezan con = se escriben como fórmulas. Sobrescribe el contenido existente, por eso exige confirmar=true.",
      inputSchema: {
        libro: z
          .string()
          .trim()
          .max(255)
          .optional()
          .describe("Nombre exacto del libro abierto. Si se omite, usa el libro activo."),
        hoja: z
          .string()
          .trim()
          .max(255)
          .optional()
          .describe("Nombre exacto de la hoja. Si se omite, usa la hoja activa."),
        rango: z
          .string()
          .trim()
          .regex(
            RANGO_A1,
            "Usa la celda inicial o un rango A1 válido, por ejemplo A1 o B2:D10.",
          )
          .describe("Celda inicial o rango donde empezar a escribir, por ejemplo A1."),
        valores: z
          .array(
            z.array(z.union([z.string().max(10_000), z.number(), z.boolean(), z.null()])),
          )
          .min(1, "Debe haber al menos una fila.")
          .max(2_000, "Máximo 2000 filas por escritura.")
          .refine(
            (filas) => filas.every((fila) => fila.length === filas[0]?.length),
            "Todas las filas deben tener la misma cantidad de columnas.",
          )
          .refine(
            (filas) => (filas[0]?.length ?? 0) >= 1 && (filas[0]?.length ?? 0) <= 200,
            "Cada fila debe tener entre 1 y 200 columnas.",
          )
          .refine(
            (filas) => filas.length * (filas[0]?.length ?? 0) <= 2_000,
            "La escritura no puede superar 2000 celdas en total.",
          )
          .describe(
            "Matriz de filas con los valores. Ejemplo: [[\"Fecha\",\"Cuenta\",\"Debe\",\"Haber\"],[\"2026-01-01\",\"Caja\",1000,0]]. Los textos que empiezan con = se escriben como fórmulas.",
          ),
        confirmar: z
          .literal(true)
          .describe("Debe ser true. Confirma que se pueden sobrescribir las celdas indicadas."),
      },
      annotations: { readOnlyHint: false, destructiveHint: true },
    },
    async ({ libro, hoja, rango, valores, confirmar }) => {
      if (confirmar !== true) {
        return error("Debes enviar confirmar=true para sobrescribir celdas.");
      }

      const entorno = await comprobarEntorno(true);
      if (!entorno.ok) return error(entorno.mensaje);

      const inicio = parsearCeldaInicial(rango);
      if (!inicio) {
        return error("El rango no es válido. Usa una celda inicial A1 como A1 o B2.");
      }

      const filas = valores as Valor[][];
      const nRows = filas.length;
      const nCols = filas[0]?.length ?? 0;
      const formulas: { direccion: string; formula: string }[] = [];
      const argumentos: string[] = [libro ?? "", hoja ?? "", rango, String(nRows), String(nCols)];

      const codificados: string[] = [];
      for (let f = 0; f < nRows; f++) {
        const fila = filas[f] ?? [];
        for (let c = 0; c < nCols; c++) {
          const valor = fila[c] ?? null;
          if (typeof valor === "string" && valor.startsWith("=")) {
            formulas.push({
              direccion: direccionCelda(inicio.fila + f, inicio.columna + c),
              formula: valor,
            });
            codificados.push("S:");
          } else {
            codificados.push(codificarValor(valor));
          }
        }
      }

      argumentos.push(String(formulas.length), ...codificados);
      for (const formula of formulas) {
        argumentos.push(formula.direccion, formula.formula);
      }

      const r = await ejecutarAppleScript(SCRIPT_ESCRIBIR, argumentos, 45_000);
      if (!r.ok) return error(r.mensaje);

      return json({
        mensaje: "Datos escritos correctamente.",
        direccion: r.salida,
        filas: nRows,
        columnas: nCols,
        formulas_escritas: formulas.length,
      });
    },
  );

  server.registerTool(
    "guardar_libro",
    {
      title: "Guardar un libro como archivo",
      description:
        "Guarda un libro abierto en una ruta absoluta .xlsx, .xlsm, .xls o .csv. Puede sobrescribir el archivo de destino, por eso exige confirmar=true.",
      inputSchema: {
        libro: z
          .string()
          .trim()
          .max(255)
          .optional()
          .describe("Nombre exacto del libro abierto. Si se omite, usa el libro activo."),
        ruta: z
          .string()
          .trim()
          .min(1)
          .max(1024)
          .describe(
            "Ruta absoluta de destino, por ejemplo /Users/ana/Documentos/contabilidad.xlsx.",
          ),
        confirmar: z
          .literal(true)
          .describe("Debe ser true. Confirma que se puede sobrescribir el archivo de destino."),
      },
      annotations: { readOnlyHint: false, destructiveHint: true },
    },
    async ({ libro, ruta, confirmar }) => {
      if (confirmar !== true) {
        return error("Debes enviar confirmar=true para guardar y sobrescribir el archivo.");
      }

      const entorno = await comprobarEntorno(true);
      if (!entorno.ok) return error(entorno.mensaje);

      const problema = validarRuta(ruta, EXTENSIONES_GUARDAR, false);
      if (problema) return error(problema);

      const r = await ejecutarAppleScript(SCRIPT_GUARDAR, [libro ?? "", ruta], 60_000);
      if (!r.ok) return error(r.mensaje);

      return texto(`Libro guardado en: ${r.salida}`);
    },
  );
}
